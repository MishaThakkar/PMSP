﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSPEntity
{
    public class ProductDetails
    {
       
        public int ProductId { get; set; }
        [Display(Name = "Product Name")]
        [Required(ErrorMessage = "Product Name  is Required")]
        public string ProductName { get; set; }
        [Display(Name = "Quantity")]
        public int QuantityId { get; set; }
  
        public double Price { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public Nullable<int> EnteredBy { get; set; }
        public Nullable<System.DateTime> EnteredDate { get; set; }
        public Nullable<int> UpdateBy { get; set; }
        public Nullable<System.DateTime> UpdateDate { get; set; }

    }
}
