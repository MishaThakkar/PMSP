﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSPEntity
{
    public class StateVM
    {
        public int StateId { get; set; }
        public Nullable<int> CountryId { get; set; }
        public string StateName { get; set; }
    }
}
