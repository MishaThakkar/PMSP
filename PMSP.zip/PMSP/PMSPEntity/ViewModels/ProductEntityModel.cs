﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSPEntity.ViewModels
{
    public class ProductEntityModel
    {
        
        [Display(Name = "Product Id")]
        public int productid { get; set; }

        [Display(Name = "Product Name")]
        public string productname { get; set; }
        [Display(Name = "Product Quantity Id")]
        public int quantityid { get; set; }
        [Display(Name = "Product Price")]
        public double price { get; set; }
        [Display(Name = "Product Description")]
        public string description { get; set; }

        [Display(Name = "Product Image Path")]
        public string image { get; set; }
        [Display(Name = "Quantity Available")]
        public int quantityavl { get; set; }
        [Display(Name = "Category Id")]
        public int CategoryId { get; set; }
        [Display(Name = "Category Name")]
        public string CategoryName { get; set; }
        [Display(Name = "Location Id")]
        public int LocationId { get; set; }
        [Display(Name = "Country")]
        public string Country { get; set; }
        [Display(Name = "State")]
        public string State { get; set; }
        [Display(Name = "City")]
        public string City { get; set; }
        [Display(Name = "Address")]
        public string Address { get; set; }
        [Display(Name = "Landmark")]
        public string Landmark { get; set; }
        [Display(Name = "Pincode")]
        public long Pincode { get; set; }

    }
}

