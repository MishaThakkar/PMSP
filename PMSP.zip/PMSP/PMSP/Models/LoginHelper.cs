﻿
using PMSPRepository.Masters.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMSP.Models
{
    public class LoginHelper
    {
        public static tbl_User GetUserDetails(tbl_User user)
        {
            using (var data = new PMSPdbEntities())
            {
                var UserDetails = data.tbl_User.Where(u => u.Email.ToLower() == user.Email.ToLower() &&
                                u.Password == user.Password).FirstOrDefault();
                return UserDetails;
            }
        }

    }
}