﻿using PagedList;
using PMSPBussinessLogic.Masters.Methods;
using PMSPEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PMSP.Controllers
{
    
    public class CategoryController : Controller
    {
        // GET: Category
        CategoryBLogic categoryBLogic = new CategoryBLogic();
        CategoryEntity categoryEntity = new CategoryEntity();

            public ActionResult CategoryList(int? page)
            {

                return View(categoryBLogic.GetAllCategories().ToPagedList(page ?? 1, 5));

            }
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]

        public ActionResult Create(CategoryEntity categoryEntity)
        {
                this.categoryBLogic.AddCategory(categoryEntity);
                return RedirectToAction("CategoryList");
        }
        public ActionResult Details(int Id)
        {
            categoryEntity = categoryBLogic.Find(Id);
            return View(categoryEntity);

        }
        [HttpGet]
        public ActionResult Edit(int Id)
        {
            categoryEntity = categoryBLogic.Find(Id);
            return View(categoryEntity);
        }

        // POST: Prouct/Edit/5
        [HttpPost]
        public ActionResult Edit(int Id, CategoryEntity categoryEntity)
        {
            this.categoryBLogic.EditCategory(categoryEntity);
            return RedirectToAction("CategoryList");
        }
        // GET: Prouct/Delete/5
        [HttpGet]
        public ActionResult Delete(int Id)
        {
            categoryEntity = categoryBLogic.Find(Id);
            return View(categoryEntity);
        }

        // POST: Prouct/Delete/5
        [HttpPost]
        public ActionResult Delete(int Id, CategoryEntity categoryEntity)
        {

            this.categoryBLogic.Delete(Id);
            return RedirectToAction("CategoryList");
        }

    }
}
