﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMSPBussinessLogic.Masters.Methods;
using PMSPRepository.Masters.Models;
using PMSPEntity;
using System.Data.Entity;
using PagedList;
using PagedList.Mvc;
using AutoMapper;
using System.IO;
using System.Net;

namespace PMSP.Controllers
{
    public class HomeController : Controller
    {
        private ProductBLogic productBLogic = new ProductBLogic();
  
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ProductList(int? page)
        {
            
            return View(productBLogic.GetAllProducts().ToPagedList(page ?? 1,5));

        }
        // GET: Product/Create
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]

        public ActionResult Create(HttpPostedFileBase image,ProductDetails productDetails)
        {
            

            //if (ModelState.IsValid)
            //{
                string filename = Path.GetFileNameWithoutExtension(productDetails.Image);
            string _filename = DateTime.Now.ToString("yymmssfff") + filename;
                string extension = Path.GetExtension(productDetails.Image);
            string path = Path.Combine(Server.MapPath("~/Image/"), _filename);
                filename = filename + extension;

                productDetails.Image = "~/Image/" + filename;

                 if (ModelState.IsValid)
                 { 
                this.productBLogic.AddProducts(productDetails);
                return RedirectToAction("ProductList");
                 }
    
            return View(productDetails);
        }
        // GET: Prouct/Details/5
        public ActionResult Details(int Id)
        {
            ProductDetails product_Master = productBLogic.Find(Id);
            return View(product_Master);

        }
        [HttpGet]
        [Route("Edit/{ProductId}")]
        public ActionResult Edit(int Id)
        {
          
            ProductDetails product_Master= productBLogic.Find(Id);
         
           
            return View(product_Master);
        }

        // POST: Prouct/Edit/5
        [HttpPost]
        public ActionResult Edit(int Id, ProductDetails productDetails, HttpPostedFileBase image)
        {

            if (image != null)
            {
                string filename = Path.GetFileNameWithoutExtension(image.FileName);
                string _filename = DateTime.Now.ToString("yymmssfff") + filename;
                string extension = Path.GetExtension(image.FileName);
                string path = Path.Combine(Server.MapPath("~/Image/"), _filename);
                filename = filename + extension;

                productDetails.Image = "~/Image/" + filename;


            }

            this.productBLogic.EditProduct(productDetails);
            return RedirectToAction("ProductList");

        
}
// GET: Prouct/Delete/5
[HttpGet]
        [Route("Delete/{ProductId}")]
        public ActionResult Delete(int Id)
        {
            ProductDetails product_Master = productBLogic.Find(Id);
            return View(product_Master);
        }

        // POST: Prouct/Delete/5
        [HttpPost]
        public ActionResult Delete(int Id,ProductDetails pd)
        {
            
            this.productBLogic.Delete(Id);
            return RedirectToAction("ProductList");
        }
       
    }
}