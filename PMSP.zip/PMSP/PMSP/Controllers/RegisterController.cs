﻿using PMSPRepository.Masters.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PMSP.Controllers
{
    public class RegisterController : Controller
    {
        // GET: User
        public ActionResult Index()

        {
            return View();
        }
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(tbl_User tbl_User)
        {

            var db = new PMSPdbEntities();
            
           
            
                if (ModelState.IsValid)
                {
                    db.tbl_User.Add(tbl_User);
                    db.SaveChanges();
                }
            
            return RedirectToAction("Index","Login");
        }
    }
}