﻿
//using PMSP.Models;
using PMSP.Models;
using PMSPRepository.Masters.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace PMSP.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(tbl_User user)
        {
            user.FirstName = "";
            user.Address = "";
            user.ContactNo = 0;
            user.LastName = "";


            if (!ModelState.IsValid)
            {

                return View();
            }
            user = LoginHelper.GetUserDetails(user);
            if (user != null)
            {
                var data = new PMSPdbEntities();
                var UID = data.tbl_User.Where(u => u.Email == user.Email).FirstOrDefault().UserId;
                var UserDetails = data.tbl_Role_Master.Where(u => u.RoleId == user.RoleId).FirstOrDefault();
                Session["Email"] = user.Email;
                FormsAuthentication.SetAuthCookie(user.Email, false);
                var authTicket = new FormsAuthenticationTicket(1, user.Email, DateTime.Now, DateTime.Now.AddMinutes(20), false, UserDetails.RoleName);
                string encryptedTicket = FormsAuthentication.Encrypt(authTicket);
                var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                HttpContext.Response.Cookies.Add(authCookie);
                if (UserDetails.RoleName == "admin")
                {
                    return RedirectToAction("Admin", "Dashboard");
                }
                else
                {
                    return RedirectToAction("Users", "Dashboard");
                }
            }
            else
            {
                ModelState.AddModelError("", "Invalid login attempt.");
                return View();
            }
            
           
        }
    }
}