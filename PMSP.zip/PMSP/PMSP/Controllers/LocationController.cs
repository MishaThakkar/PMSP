﻿using PagedList;
using PMSPBussinessLogic.Masters.Methods;
using PMSPEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PMSP.Controllers
{
    public class LocationController : Controller
    {
        LocationBLogic locationBLogic = new LocationBLogic();
        LocationEntity locationEntity = new LocationEntity();

        // GET: Location
        public ActionResult Index()
        {
            return View();
        }
        // GET: Category
       
        public ActionResult LocationList(int? page)
        {


            return View(locationBLogic.GetAllLocation().ToPagedList(page ?? 1, 5));

        }
        public ActionResult Create()
        {
            ViewBag.CountryId = new SelectList(locationEntity.Countries, "CountryId", "CountryName");
            var Countries = this.locationBLogic.GetCountriesBL();
            return View(Countries);
        }

        [HttpPost]

        public ActionResult Create(LocationEntity locationEntity, int? countryId, int? stateId, int? cityId)
        {
            if (locationEntity.Address == null)
            {

                var Countries = this.locationBLogic.getLocationData(countryId, stateId, cityId);
                return View(Countries);
            }
            else
            {
                this.locationBLogic.AddLocation(locationEntity);
                ViewBag.CountryId = new SelectList(locationEntity.Countries, "CountryId", "CountryName", locationEntity.CountryId );
                return RedirectToAction("LocationList");
            }
           


        }
        [HttpGet]
        public ActionResult Details(int Id)
        {
             locationEntity = locationBLogic.Find(Id);
            return View(locationEntity);

        }
        [HttpGet]
        public ActionResult Edit(int Id)
        {
            locationEntity = locationBLogic.Find(Id);
            return View(locationEntity);
        }

        //// POST: Prouct/Edit/5
        //[HttpPost]
        //public ActionResult Edit(int Id, CategoryEntity categoryEntity)
        //{
        //    this.categoryBLogic.EditCategory(categoryEntity);
        //    return RedirectToAction("CategoryList");
        //}
        //// GET: Prouct/Delete/5
        //[HttpGet]
        //public ActionResult Delete(int Id)
        //{
        //    categoryEntity = categoryBLogic.Find(Id);
        //    return View(categoryEntity);
        //}

        //// POST: Prouct/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int Id, CategoryEntity categoryEntity)
        //{

        //    this.categoryBLogic.Delete(Id);
        //    return RedirectToAction("CategoryList");
        //}

    }
}