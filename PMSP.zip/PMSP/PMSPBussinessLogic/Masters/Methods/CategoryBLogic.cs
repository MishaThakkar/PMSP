﻿using PMSPEntity;
using PMSPRepository.Masters.Methods;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSPBussinessLogic.Masters.Methods
{
    public   class CategoryBLogic
    {
        CategoryRepository categoryRepository = new CategoryRepository();
        public List<CategoryEntity> GetAllCategories()
        {

            return categoryRepository.GetAllCategory();

        }
        public void AddCategory(CategoryEntity categoryEntity)
        {
            categoryRepository.AddCategory(categoryEntity);

        }
        public CategoryEntity Find(int id)
        {
            return categoryRepository.Find(id);

        }

        public void EditCategory(CategoryEntity categoryEntity)
        {
            categoryRepository.EditCategory(categoryEntity);
        }
        public void Delete(int Id)
        {
            categoryRepository.Delete(Id);
        }
    }
}
