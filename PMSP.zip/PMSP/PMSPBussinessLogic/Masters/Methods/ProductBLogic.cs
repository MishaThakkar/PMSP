﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMSPRepository.Masters.Methods;
using PMSPRepository.Masters.Models;
using PMSPRepository.Masters.ViewModels;
using PMSPEntity;
using AutoMapper;
namespace PMSPBussinessLogic.Masters.Methods
{
    public class ProductBLogic
    {
        private ProductRepository productRepository = new ProductRepository();
        public List<ProductDetails> GetAllProducts()
        {
           
                return productRepository.GetAllProducts();
            
        }
        public void AddProducts(ProductDetails productDetails) {
             productRepository.AddProducts(productDetails);

        }
        public ProductDetails Find(int id)
        {
            return productRepository.Find(id);

        }
      
        public void EditProduct(ProductDetails productDetails)
        {
            productRepository.EditProduct(productDetails);
        }
        public void Delete(int Id)
        {
            productRepository.Delete(Id);
        }

       

    }
}
