﻿using PMSPEntity;
using PMSPRepository.Masters.Methods;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSPBussinessLogic.Masters.Methods
{
   public class LocationBLogic
    {
        LocationRepository locationRepository = new LocationRepository();

        public List<LocationEntity> GetAllLocation()
        {

            return locationRepository.GetAllLocation();

        }

        public LocationEntity GetCountriesBL()
        {
            var countries = locationRepository.GetCountries();
            return countries;
        }
        public LocationEntity getLocationData(int? countryId, int? stateId, int? cityId)
        {
            var countries = locationRepository.getLocationData( countryId,  stateId,  cityId);
            return countries;
        }
        public void AddLocation(LocationEntity locationEntity)
        {

            locationRepository.AddLocation(locationEntity);

        }
        public LocationEntity Find(int id)
        {
            return locationRepository.Find(id);

        }

        public void EditLocation(LocationEntity locationEntity)
        {
            locationRepository.EditLocation(locationEntity);
        }
        public void Delete(int Id)
        {
            locationRepository.Delete(Id);
        }


    }
}
