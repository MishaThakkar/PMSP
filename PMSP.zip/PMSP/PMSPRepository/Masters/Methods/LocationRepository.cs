﻿using AutoMapper;
using PMSPEntity;
using PMSPRepository.Masters.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace PMSPRepository.Masters.Methods
{
    public class LocationRepository
    {
        PMSPdbEntities pMSPdbEntities = new PMSPdbEntities();
        List<tbl_Location_Master> tbl_Location_Masters = new List<tbl_Location_Master>();
        tbl_Location_Master location_Master = new tbl_Location_Master();
        List<LocationEntity> locationEntities = new List<LocationEntity>();
        LocationEntity location = new LocationEntity();
        List<tbl_Location_Country> tbl_Location_Countries = new List<tbl_Location_Country>();
        List<tbl_Location_State> tbl_Location_States = new List<tbl_Location_State>();
        List<tbl_Location_City> tbl_Location_Cities = new List<tbl_Location_City>();
        public LocationRepository()
        {
            tbl_Location_Countries = pMSPdbEntities.tbl_Location_Country.ToList();
            tbl_Location_States = pMSPdbEntities.tbl_Location_State.ToList();
            tbl_Location_Cities = pMSPdbEntities.tbl_Location_City.ToList();

        }
       // public List<tbl_Location_Country> GetALLCountries()
        //{
        //    return pMSPdbEntities.tbl_Location_Country.ToList();
        //}
        public List<LocationEntity> GetAllLocation()
        {

            tbl_Location_Masters = pMSPdbEntities.tbl_Location_Master.ToList();

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<tbl_Location_Master, LocationEntity>();
            });

            IMapper mapper = config.CreateMapper();

            locationEntities = mapper.Map<List<tbl_Location_Master>, List<LocationEntity>>(tbl_Location_Masters);
            foreach(var i in locationEntities)
            {
                i.CountryName = tbl_Location_Countries.Where(x => x.CountryId == i.CountryId).FirstOrDefault().CountryName;
                i.StateName = tbl_Location_States.Where(x => x.StateId == i.StateId).FirstOrDefault().StateName;
                i.CityName = tbl_Location_Cities.Where(x => x.CityId == i.CityId).FirstOrDefault().CityName;
            }
            return locationEntities;
      


        }
        public LocationEntity GetCountries()
        {

            LocationEntity model = new LocationEntity();
            foreach (var country in pMSPdbEntities.tbl_Location_Country)
            {
                model.Countries.Add(new SelectListItem
                {
                    Text = country.CountryName,
                    Value = country.CountryId.ToString()
                });
            }

            return model;

        }
      
        public LocationEntity getLocationData(int? countryId, int? stateId, int? cityId)
        {
            LocationEntity model = new LocationEntity();
            foreach (var country in pMSPdbEntities.tbl_Location_Country)
            {
                model.Countries.Add(new SelectListItem { Text = country.CountryName, Value = country.CountryId.ToString() });
            }

            if (countryId.HasValue)
            {
                var states = (from state in pMSPdbEntities.tbl_Location_State
                              where state.CountryId == countryId.Value
                              select state).ToList();
                foreach (var state in states)
                {
                    model.States.Add(new SelectListItem { Text = state.StateName, Value = state.StateId.ToString() });
                }

                if (stateId.HasValue)
                {
                    var cities = (from city in pMSPdbEntities.tbl_Location_City
                                  where city.StateId == stateId.Value
                                  select city).ToList();
                    foreach (var city in cities)
                    {
                        model.Cities.Add(new SelectListItem { Text = city.CityName, Value = city.CityId.ToString() });
                    }
                }
            }
            return model;
        
    }
        public void AddLocation(LocationEntity locationEntity)
        {
            
          

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<LocationEntity, tbl_Location_Master>();
            });

            IMapper mapper = config.CreateMapper();
            location_Master = mapper.Map<LocationEntity, tbl_Location_Master>(locationEntity);
            location_Master = pMSPdbEntities.tbl_Location_Master.Add(location_Master);
            pMSPdbEntities.SaveChanges();


        }
        public LocationEntity Find(int id)
        {

            locationEntities = GetAllLocation();
            location = locationEntities.Where(x => x.LocationId == id).FirstOrDefault();
            return location;


        }
        public void EditLocation(LocationEntity locationEntity)
        {
          

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<LocationEntity, tbl_Location_Master>();
            });

            IMapper mapper = config.CreateMapper();
            location_Master = mapper.Map<LocationEntity, tbl_Location_Master>(location);
            var context = new PMSPdbEntities();
            {

                context.Entry(location_Master).State = EntityState.Modified;
                context.SaveChanges();
            }
        }

        public void Delete(int Id)
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<LocationEntity, tbl_Location_Master>();
            });
            IMapper mapper = config.CreateMapper();
            location_Master = mapper.Map<LocationEntity, tbl_Location_Master>(location);
            var context = new PMSPdbEntities();
            context.tbl_Location_Master.Remove(context.tbl_Location_Master.Single(a => a.LocationId == Id));
            context.SaveChanges();

        }

    }
}
