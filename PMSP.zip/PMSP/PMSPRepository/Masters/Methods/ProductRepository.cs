﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMSPRepository.Masters.Models;
using PMSPEntity;
using AutoMapper;
using PMSPRepository.Masters.ViewModels;
using System.Data.Entity;

namespace PMSPRepository.Masters.Methods
{
    public class ProductRepository
    {
        PMSPdbEntities pMSPdbEntities = new PMSPdbEntities();
        List<ProductDetails> productDetails = new List<ProductDetails>();
        List<ProductViewModel> productViewModel = new List<ProductViewModel>();
        List<tbl_Product_Master> products = new List<tbl_Product_Master>();
        public List<ProductDetails> GetAllProducts()
        {
          
            //var context = new tbl_Product_Master();
            products = pMSPdbEntities.tbl_Product_Master.ToList();
          
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<tbl_Product_Master, ProductDetails>();
            });

            IMapper mapper = config.CreateMapper();

            productDetails = mapper.Map<List<tbl_Product_Master>, List<ProductDetails>>(products);
       
            return productDetails;
          
        }
        public void AddProducts(ProductDetails productDetails)
        {
            tbl_Product_Master products = new tbl_Product_Master();

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap< ProductDetails,tbl_Product_Master > ();
            });

            IMapper mapper = config.CreateMapper();
            products = mapper.Map<ProductDetails, tbl_Product_Master>(productDetails);
            products = pMSPdbEntities.tbl_Product_Master.Add(products);
            pMSPdbEntities.SaveChanges();
          

        }

        //public ProductDetails Find(int id)
        //{
        //    return this.pMSPDBEntities.tbl_Product_Master.Find(id);
        //}
       
        public ProductDetails Find(int id)
        {
            ProductDetails prd = new ProductDetails();
            List<tbl_Product_Master> tpm = new List<tbl_Product_Master>();
            List<ProductDetails> prdl = new List<ProductDetails>();
            prdl = GetAllProducts();
            prd = prdl.Where(x => x.ProductId == id).FirstOrDefault();
            return prd;


        }
        public  void EditProduct(ProductDetails productDetails)
        {
           
            tbl_Product_Master products = new tbl_Product_Master();

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<ProductDetails, tbl_Product_Master>();
            });

            IMapper mapper = config.CreateMapper();
            products = mapper.Map<ProductDetails, tbl_Product_Master>(productDetails);
            var context = new PMSPdbEntities();
            {
                //context.tbl_Product_Master.Where(x => x.ProductId == productDetails.ProductId).FirstOrDefault().ProductId=productDetails.ProductId;
                //context.tbl_Product_Master.First<tbl_Product_Master>();
                context.Entry(products).State = EntityState.Modified;
                context.SaveChanges();
            }
        }

        public void Delete(int Id)
        {
            
            ProductDetails pd = new ProductDetails();
            tbl_Product_Master tbl_Product_Master = new tbl_Product_Master();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<ProductDetails, tbl_Product_Master>();
            });
            IMapper mapper = config.CreateMapper();
            tbl_Product_Master = mapper.Map<ProductDetails, tbl_Product_Master>(pd);
            var context = new PMSPdbEntities();
            context.tbl_Product_Master.Remove(context.tbl_Product_Master.Single(a => a.ProductId == Id));
            context.SaveChanges();
          
        }
         
        }
}
