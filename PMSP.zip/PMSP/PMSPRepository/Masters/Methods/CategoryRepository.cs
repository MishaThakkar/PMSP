﻿using PMSPEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMSPRepository.Masters.Models;
using AutoMapper;
using System.Data.Entity;

namespace PMSPRepository.Masters.Methods
{
    public class CategoryRepository
    {
        PMSPdbEntities pMSPdbEntities = new PMSPdbEntities();
        List<tbl_Category_Master> tbl_Categories = new List<tbl_Category_Master>();
        tbl_Category_Master category_Master = new tbl_Category_Master();
        List<CategoryEntity> categoryEntities = new List<CategoryEntity>();
        CategoryEntity category = new CategoryEntity();
        public List<CategoryEntity> GetAllCategory()
        {
          
           
            tbl_Categories = pMSPdbEntities.tbl_Category_Master.ToList();

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<tbl_Category_Master, CategoryEntity>();
            });

            IMapper mapper = config.CreateMapper();

            categoryEntities = mapper.Map<List<tbl_Category_Master>, List<CategoryEntity>>(tbl_Categories);

            return categoryEntities;

        }
        public void AddCategory(CategoryEntity categoryEntity)
        {
          

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<CategoryEntity, tbl_Category_Master>();
            });

            IMapper mapper = config.CreateMapper();
            category_Master = mapper.Map<CategoryEntity, tbl_Category_Master>(categoryEntity);
            category_Master = pMSPdbEntities.tbl_Category_Master.Add(category_Master);
            pMSPdbEntities.SaveChanges();


        }
        public CategoryEntity Find(int id)
        {
           
            categoryEntities = GetAllCategory();
            category = categoryEntities.Where(x => x.CategoryId == id).FirstOrDefault();
            return category;


        }
        public void EditCategory(CategoryEntity categoryEntity)
        {
            tbl_Category_Master category_Master = new tbl_Category_Master();

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<CategoryEntity, tbl_Category_Master>();
            });

            IMapper mapper = config.CreateMapper();
            category_Master = mapper.Map<CategoryEntity, tbl_Category_Master>(categoryEntity);
            var context = new PMSPdbEntities();
            {
                
                context.Entry(category_Master).State = EntityState.Modified;
                context.SaveChanges();
            }
        }

        public void Delete(int Id)
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<CategoryEntity, tbl_Category_Master>();
            });
            IMapper mapper = config.CreateMapper();
            category_Master = mapper.Map<CategoryEntity, tbl_Category_Master>(category);
            var context = new PMSPdbEntities();
            context.tbl_Category_Master.Remove(context.tbl_Category_Master.Single(a => a.CategoryId == Id));
            context.SaveChanges();

        }

    }
}

